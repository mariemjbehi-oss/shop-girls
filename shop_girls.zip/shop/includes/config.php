<?php
// includes/config.php
// ============================================
// Configuration de la base de données (PostgreSQL)
// ============================================

define('DB_HOST', 'localhost');
define('DB_PORT', '5432');
define('DB_NAME', 'shop_db');
define('DB_USER', 'postgres');
define('DB_PASS', 'votre_mot_de_passe');  // ← Remplacez par votre mot de passe PostgreSQL

define('SITE_NAME', 'ShopPHP');
define('CURRENCY', 'TND');

/**
 * Connexion PDO à PostgreSQL
 */
function getConnection(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "pgsql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME;
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            die("Erreur de connexion : " . $e->getMessage());
        }
    }
    return $pdo;
}
