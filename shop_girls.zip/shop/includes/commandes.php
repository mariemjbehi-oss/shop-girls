<?php
// includes/commandes.php
// ============================================
// Gestion des commandes en base de données (PostgreSQL)
// ============================================

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/panier.php';

function enregistrerCommande(string $nom_client, string $email_client): int|false {
    $panier = getPanier();
    if (empty($panier)) return false;

    $pdo = getConnection();
    $total = calculerTotal();

    try {
        $pdo->beginTransaction();

        // RETURNING id est spécifique à PostgreSQL
        $stmt = $pdo->prepare("
            INSERT INTO commandes (nom_client, email_client, total, statut)
            VALUES (:nom, :email, :total, 'confirmée')
            RETURNING id
        ");
        $stmt->execute([
            ':nom'   => trim($nom_client),
            ':email' => trim($email_client),
            ':total' => $total,
        ]);
        $commande_id = (int)$stmt->fetchColumn();

        $stmtLigne = $pdo->prepare("
            INSERT INTO lignes_commande (commande_id, produit_id, quantite, prix_unitaire)
            VALUES (:commande_id, :produit_id, :quantite, :prix)
        ");

        foreach ($panier as $item) {
            $stmtLigne->execute([
                ':commande_id' => $commande_id,
                ':produit_id'  => $item['id'],
                ':quantite'    => $item['quantite'],
                ':prix'        => $item['prix'],
            ]);
        }

        $pdo->commit();
        return $commande_id;

    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Erreur commande: " . $e->getMessage());
        return false;
    }
}

function getCommandeDetails(int $commande_id): ?array {
    $pdo = getConnection();

    $stmt = $pdo->prepare("SELECT * FROM commandes WHERE id = :id");
    $stmt->execute([':id' => $commande_id]);
    $commande = $stmt->fetch();
    if (!$commande) return null;

    $stmtLignes = $pdo->prepare("
        SELECT lc.*, p.nom AS produit_nom
        FROM lignes_commande lc
        JOIN produits p ON lc.produit_id = p.id
        WHERE lc.commande_id = :id
    ");
    $stmtLignes->execute([':id' => $commande_id]);
    $commande['lignes'] = $stmtLignes->fetchAll();

    return $commande;
}
