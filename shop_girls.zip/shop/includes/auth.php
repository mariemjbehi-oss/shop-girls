<?php
// includes/auth.php
// ============================================
// Fonctions d'authentification
// ============================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Connecte un utilisateur — vérifie email + mot de passe
 * Retourne l'utilisateur ou false
 */
function connecterUtilisateur(string $email, string $mot_de_passe): array|false {
    $pdo  = getConnection();
    $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE email = :email LIMIT 1");
    $stmt->execute([':email' => trim($email)]);
    $user = $stmt->fetch();

    // password_verify() compare le mot de passe saisi avec le hash en BD
    if ($user && password_verify($mot_de_passe, $user['mot_de_passe'])) {
        // Stocker les infos de l'utilisateur dans la session
        $_SESSION['user'] = [
            'id'    => $user['id'],
            'nom'   => $user['nom'],
            'email' => $user['email'],
            'role'  => $user['role'],  // 'admin' ou 'client'
        ];
        return $_SESSION['user'];
    }
    return false;
}

/**
 * Déconnecte l'utilisateur — vide la session
 */
function deconnecterUtilisateur(): void {
    unset($_SESSION['user']);
    // Vider aussi le panier à la déconnexion
    unset($_SESSION['panier']);
}

/**
 * Vérifie si quelqu'un est connecté
 */
function estConnecte(): bool {
    return isset($_SESSION['user']);
}

/**
 * Vérifie si l'utilisateur connecté est Admin
 */
function estAdmin(): bool {
    return isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin';
}

/**
 * Retourne les infos de l'utilisateur connecté
 */
function utilisateurConnecte(): ?array {
    return $_SESSION['user'] ?? null;
}

/**
 * Redirige vers login.php si non connecté
 */
function exigerConnexion(): void {
    if (!estConnecte()) {
        $_SESSION['flash'] = "⚠️ Veuillez vous connecter pour accéder à cette page.";
        header('Location: login.php');
        exit;
    }
}

/**
 * Redirige vers index.php si non admin
 */
function exigerAdmin(): void {
    exigerConnexion();
    if (!estAdmin()) {
        $_SESSION['flash'] = "⛔ Accès réservé à l'administratrice.";
        header('Location: index.php');
        exit;
    }
}
