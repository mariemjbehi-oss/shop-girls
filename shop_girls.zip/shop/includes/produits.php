<?php
// includes/produits.php
// ============================================
// Fonctions CRUD pour les produits
// ============================================

require_once __DIR__ . '/config.php';

/**
 * Récupère tous les produits avec leur catégorie
 */
function getTousProduits(): array {
    $pdo = getConnection();
    $stmt = $pdo->query("
        SELECT p.*, c.nom AS categorie_nom
        FROM produits p
        LEFT JOIN categories c ON p.categorie_id = c.id
        ORDER BY p.id ASC
    ");
    return $stmt->fetchAll();
}

/**
 * Récupère les produits d'une catégorie
 */
function getProduitsByCategorie(int $categorie_id): array {
    $pdo = getConnection();
    $stmt = $pdo->prepare("
        SELECT p.*, c.nom AS categorie_nom
        FROM produits p
        LEFT JOIN categories c ON p.categorie_id = c.id
        WHERE p.categorie_id = :cat_id
        ORDER BY p.nom
    ");
    $stmt->execute([':cat_id' => $categorie_id]);
    return $stmt->fetchAll();
}

/**
 * Récupère un produit par son ID
 */
function getProduitById(int $id): ?array {
    $pdo = getConnection();
    $stmt = $pdo->prepare("
        SELECT p.*, c.nom AS categorie_nom
        FROM produits p
        LEFT JOIN categories c ON p.categorie_id = c.id
        WHERE p.id = :id
    ");
    $stmt->execute([':id' => $id]);
    $result = $stmt->fetch();
    return $result ?: null;
}

/**
 * Récupère toutes les catégories
 */
function getCategories(): array {
    $pdo = getConnection();
    $stmt = $pdo->query("SELECT * FROM categories ORDER BY nom");
    return $stmt->fetchAll();
}

/**
 * Recherche de produits par nom
 */
function rechercherProduits(string $terme): array {
    $pdo = getConnection();
    $stmt = $pdo->prepare("
        SELECT p.*, c.nom AS categorie_nom
        FROM produits p
        LEFT JOIN categories c ON p.categorie_id = c.id
        WHERE p.nom ILIKE :terme OR p.description ILIKE :terme
        ORDER BY p.nom
    ");
    $stmt->execute([':terme' => '%' . $terme . '%']);
    return $stmt->fetchAll();
}
