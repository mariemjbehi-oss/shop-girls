<?php
// includes/panier.php
// ============================================
// Gestion du panier via les sessions PHP
// ============================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Initialise le panier dans la session
 */
function initPanier(): void {
    if (!isset($_SESSION['panier'])) {
        $_SESSION['panier'] = [];
    }
}

/**
 * Ajoute un produit au panier
 */
function ajouterAuPanier(int $produit_id, string $nom, float $prix, int $quantite = 1): void {
    initPanier();
    if (isset($_SESSION['panier'][$produit_id])) {
        $_SESSION['panier'][$produit_id]['quantite'] += $quantite;
    } else {
        $_SESSION['panier'][$produit_id] = [
            'id'       => $produit_id,
            'nom'      => $nom,
            'prix'     => $prix,
            'quantite' => $quantite,
        ];
    }
}

/**
 * Modifie la quantité d'un produit dans le panier
 */
function modifierQuantite(int $produit_id, int $quantite): void {
    initPanier();
    if ($quantite <= 0) {
        supprimerDuPanier($produit_id);
    } elseif (isset($_SESSION['panier'][$produit_id])) {
        $_SESSION['panier'][$produit_id]['quantite'] = $quantite;
    }
}

/**
 * Supprime un produit du panier
 */
function supprimerDuPanier(int $produit_id): void {
    initPanier();
    unset($_SESSION['panier'][$produit_id]);
}

/**
 * Vide le panier
 */
function viderPanier(): void {
    $_SESSION['panier'] = [];
}

/**
 * Retourne tous les articles du panier
 */
function getPanier(): array {
    initPanier();
    return $_SESSION['panier'];
}

/**
 * Calcule le total du panier
 */
function calculerTotal(): float {
    $total = 0.0;
    foreach (getPanier() as $item) {
        $total += $item['prix'] * $item['quantite'];
    }
    return $total;
}

/**
 * Retourne le nombre d'articles dans le panier
 */
function getNombreArticles(): int {
    $total = 0;
    foreach (getPanier() as $item) {
        $total += $item['quantite'];
    }
    return $total;
}

/**
 * Vérifie si le panier est vide
 */
function panierEstVide(): bool {
    return empty(getPanier());
}
