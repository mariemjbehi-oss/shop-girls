<?php
// includes/nav.php — Navigation commune à toutes les pages
// Inclure ce fichier dans chaque page pour avoir la même nav
require_once __DIR__ . '/auth.php';
$user       = utilisateurConnecte();
$nb_articles = function_exists('getNombreArticles') ? getNombreArticles() : 0;
?>
<nav>
    <a class="nav-brand" href="index.php">
        Belle & Rose
        <span>✦ Beauté & Organisation</span>
    </a>
    <div class="nav-links">

        <?php if ($user): ?>
            <!-- Utilisateur connecté -->
            <?php if ($user['role'] === 'admin'): ?>
                <a href="admin.php" class="nav-link-admin">👑 Administration</a>
            <?php endif; ?>
            <a href="index.php">Boutique</a>

            <!-- Info utilisateur -->
            <span class="nav-user">🌸 <?= htmlspecialchars($user['nom']) ?></span>

            <!-- Panier (seulement pour les clients) -->
            <?php if ($user['role'] === 'client'): ?>
                <a href="panier.php" class="btn-cart">
                    🛍️ Panier
                    <?php if ($nb_articles > 0): ?>
                        <span class="cart-badge"><?= $nb_articles ?></span>
                    <?php endif; ?>
                </a>
            <?php endif; ?>

            <!-- Déconnexion -->
            <a href="logout.php" class="btn-logout">Déconnexion</a>

        <?php else: ?>
            <!-- Visiteur non connecté -->
            <a href="index.php">Boutique</a>
            <a href="login.php" class="btn-secondary btn" style="padding:0.5rem 1.2rem">🔑 Connexion</a>
            <a href="panier.php" class="btn-cart">
                🛍️ Panier
                <?php if ($nb_articles > 0): ?>
                    <span class="cart-badge"><?= $nb_articles ?></span>
                <?php endif; ?>
            </a>
        <?php endif; ?>

    </div>
</nav>
