/**
 * Belle & Rose — app.js
 * =====================
 * Ce fichier JavaScript gère toute l'interactivité du site.
 * Il s'exécute automatiquement quand la page est complètement chargée.
 */

// "DOMContentLoaded" = attendre que la page HTML soit prête avant d'exécuter le code
document.addEventListener('DOMContentLoaded', () => {


    /* ============================================================
       1. FLASH MESSAGE
       Le petit message rose qui apparaît après avoir ajouté un produit.
       On le fait disparaître automatiquement après 3 secondes.
    ============================================================ */

    const flash = document.querySelector('.flash'); // cherche l'élément avec la classe "flash"

    if (flash) { // si ce message existe sur la page...
        setTimeout(() => { // ...attendre 3000ms (3 secondes) puis :
            flash.style.transition = 'opacity 0.5s, transform 0.5s'; // animation douce
            flash.style.opacity    = '0';                             // rendre invisible
            flash.style.transform  = 'translateX(120%)';              // faire glisser vers la droite
            setTimeout(() => flash.remove(), 500); // supprimer du HTML après l'animation
        }, 3000);
    }


    /* ============================================================
       2. FILTRES DE CATÉGORIE (sans rechargement de page)
       Quand on clique sur "Maquillage", seuls les produits
       de cette catégorie s'affichent — instantanément.
    ============================================================ */

    // Récupérer tous les boutons de filtre et toutes les cartes produit
    const filterBtns   = document.querySelectorAll('.filter-btn[data-cat]'); // ex: bouton "Maquillage"
    const productCards  = document.querySelectorAll('.product-card[data-cat]'); // ex: carte "Rouge à lèvres"
    const sectionTitle  = document.getElementById('section-title');            // le titre "Nos Essentiels Beauté"

    if (filterBtns.length > 0 && productCards.length > 0) {

        filterBtns.forEach(btn => { // pour chaque bouton de filtre...
            btn.addEventListener('click', (e) => { // ...quand on clique dessus :
                e.preventDefault(); // empêcher le lien de naviguer vers une autre page

                const cat = btn.dataset.cat; // récupérer la catégorie du bouton (ex: "2" pour Maquillage)

                // Retirer la classe "active" de tous les boutons, puis l'ajouter seulement au bouton cliqué
                filterBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');

                // Parcourir chaque carte produit pour décider si on l'affiche ou la cache
                productCards.forEach(card => {
                    // "all" = bouton "Tout voir", sinon vérifier si la carte appartient à cette catégorie
                    const match = cat === 'all' || card.dataset.cat === cat;

                    card.style.transition = 'opacity 0.25s, transform 0.25s'; // animation douce

                    if (match) {
                        // Produit visible : réafficher normalement
                        card.style.opacity   = '1';
                        card.style.transform = 'scale(1)';
                        card.style.display   = '';
                    } else {
                        // Produit caché : rétrécir et rendre transparent
                        card.style.opacity   = '0';
                        card.style.transform = 'scale(0.96)';
                        // Après l'animation (250ms), vraiment cacher l'élément
                        setTimeout(() => { card.style.display = 'none'; }, 250);
                    }
                });

                // Changer le titre de la section selon le filtre choisi
                if (sectionTitle) {
                    sectionTitle.textContent = btn.dataset.label || 'Nos Essentiels Beauté';
                }

                // Mettre à jour l'URL dans la barre du navigateur sans recharger la page
                // Ex: passer de "/index.php" à "/index.php?cat=2"
                const url = new URL(window.location);
                if (cat === 'all') url.searchParams.delete('cat'); // supprimer le paramètre
                else               url.searchParams.set('cat', cat); // ou le mettre à jour
                url.searchParams.delete('q'); // effacer aussi la recherche en cours
                window.history.pushState({}, '', url); // appliquer la nouvelle URL
            });
        });
    }


    /* ============================================================
       3. RECHERCHE EN TEMPS RÉEL
       Pendant que l'utilisateur tape dans la barre de recherche,
       les produits qui ne correspondent pas s'estompent immédiatement.
    ============================================================ */

    const searchInput = document.querySelector('.search-input'); // la barre de recherche

    if (searchInput && productCards.length > 0) {

        // Déclencher la recherche à chaque frappe au clavier
        searchInput.addEventListener('input', () => {
            const terme = searchInput.value.toLowerCase().trim(); // texte saisi en minuscules

            productCards.forEach(card => {
                // Lire le nom, la description et la catégorie de chaque carte
                const nom  = card.querySelector('.product-name')?.textContent.toLowerCase()     || '';
                const desc = card.querySelector('.product-desc')?.textContent.toLowerCase()     || '';
                const cat  = card.querySelector('.product-category')?.textContent.toLowerCase() || '';

                // Le produit correspond si le terme est vide OU trouvé dans le nom/desc/cat
                const match = terme === '' || nom.includes(terme) || desc.includes(terme) || cat.includes(terme);

                card.style.transition    = 'opacity 0.2s';
                card.style.opacity       = match ? '1'    : '0.2'; // visible ou estompé
                card.style.pointerEvents = match ? ''     : 'none'; // cliquable ou non
            });

            // Mettre à jour le titre selon qu'il y a une recherche active ou non
            if (sectionTitle) {
                sectionTitle.textContent = terme
                    ? `Résultats pour "${terme}"`
                    : 'Nos Essentiels Beauté';
            }
        });

        // Bouton "✕" pour effacer la recherche d'un seul clic
        const clearBtn = document.getElementById('clear-search');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                searchInput.value = ''; // vider le champ
                searchInput.dispatchEvent(new Event('input')); // simuler une frappe pour réafficher tout
                clearBtn.style.display = 'none'; // cacher le bouton ✕
            });

            // Afficher le bouton ✕ seulement quand l'utilisateur a tapé quelque chose
            searchInput.addEventListener('input', () => {
                clearBtn.style.display = searchInput.value ? '' : 'none';
            });
        }
    }


    /* ============================================================
       4. PANIER — SOUS-TOTAL EN TEMPS RÉEL
       Quand on change la quantité d'un produit dans le panier,
       le sous-total et le total général se mettent à jour immédiatement,
       sans avoir besoin de cliquer sur "✓" d'abord.
    ============================================================ */

    // Pour chaque champ de quantité dans le tableau du panier
    document.querySelectorAll('.qty-input').forEach(input => {
        const row = input.closest('tr'); // la ligne du tableau qui contient ce champ

        input.addEventListener('input', () => {
            const qty  = parseInt(input.value)        || 0; // quantité saisie (nombre entier)
            const prix = parseFloat(row?.dataset.prix) || 0; // prix unitaire stocké dans data-prix="..."

            const subEl = row?.querySelector('.subtotal'); // la cellule "Sous-total" de cette ligne
            if (subEl && prix) {
                subEl.textContent = (qty * prix).toFixed(2) + ' TND'; // recalculer et afficher
            }

            updateCartTotal(); // puis recalculer aussi le total général en bas
        });
    });

    // Recalculer le total de toutes les lignes du panier
    function updateCartTotal() {
        let total = 0;

        // Additionner prix × quantité pour chaque ligne du tableau
        document.querySelectorAll('tr[data-prix]').forEach(row => {
            const qty  = parseInt(row.querySelector('.qty-input')?.value) || 0;
            const prix = parseFloat(row.dataset.prix)                     || 0;
            total += qty * prix;
        });

        // Afficher le nouveau total dans l'élément #cart-total
        const totalEl = document.getElementById('cart-total');
        if (totalEl) totalEl.textContent = total.toFixed(2) + ' TND';
    }


    /* ============================================================
       5. MODAL DE CONFIRMATION PERSONNALISÉE
       Remplace la boîte de dialogue grise du navigateur (confirm())
       par une belle fenêtre modale aux couleurs du site.
       Utilisée pour "Supprimer cet article ?" et "Vider le panier ?".
    ============================================================ */

    // Quand on clique sur un bouton poubelle 🗑️
    document.querySelectorAll('.btn-supprimer').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault(); // bloquer la navigation immédiate
            showConfirm('Supprimer cet article ?', () => {
                window.location.href = btn.href; // naviguer seulement si l'utilisateur confirme
            });
        });
    });

    // Quand on clique sur "Vider le panier"
    const btnVider = document.querySelector('.btn-vider');
    if (btnVider) {
        btnVider.addEventListener('click', (e) => {
            e.preventDefault();
            showConfirm('Vider tout le panier ?', () => {
                window.location.href = btnVider.href; // confirmer → naviguer
            });
        });
    }

    // Fonction qui crée et affiche la fenêtre modale
    function showConfirm(message, onConfirm) {
        // Supprimer une éventuelle modale déjà ouverte
        document.getElementById('modal-confirm')?.remove();

        // Créer la structure HTML de la modale dynamiquement
        const modal = document.createElement('div');
        modal.id = 'modal-confirm';
        modal.innerHTML = `
            <div class="modal-overlay">
                <div class="modal-box">
                    <p class="modal-msg">${message}</p>
                    <div class="modal-actions">
                        <button class="btn btn-secondary modal-cancel">Annuler</button>
                        <button class="btn btn-danger modal-ok">Confirmer</button>
                    </div>
                </div>
            </div>`;
        document.body.appendChild(modal); // ajouter la modale à la page

        // Bouton "Annuler" → fermer la modale
        modal.querySelector('.modal-cancel').addEventListener('click', () => modal.remove());

        // Bouton "Confirmer" → fermer + exécuter l'action (supprimer / vider)
        modal.querySelector('.modal-ok').addEventListener('click', () => {
            modal.remove();
            onConfirm();
        });

        // Cliquer en dehors de la boîte → fermer aussi
        modal.querySelector('.modal-overlay').addEventListener('click', (e) => {
            if (e.target === modal.querySelector('.modal-overlay')) modal.remove();
        });
    }


    /* ============================================================
       6. VALIDATION DU FORMULAIRE DE COMMANDE
       Vérifie le nom et l'email avant d'envoyer le formulaire.
       Les erreurs s'affichent directement sous chaque champ,
       en rouge, sans recharger la page.
    ============================================================ */

    const checkoutForm = document.getElementById('checkout-form');
    if (checkoutForm) {
        const nomInput   = document.getElementById('nom');
        const emailInput = document.getElementById('email');

        // Valider un champ quand l'utilisateur le quitte (perd le focus)
        [nomInput, emailInput].forEach(input => {
            if (!input) return;
            input.addEventListener('blur',  () => validateField(input));  // quand on quitte le champ
            input.addEventListener('input', () => clearError(input));     // effacer l'erreur dès qu'on retape
        });

        // Valider tout le formulaire à la soumission
        checkoutForm.addEventListener('submit', (e) => {
            let valid = true;

            if (nomInput && !nomInput.value.trim()) {
                showError(nomInput, 'Le nom est requis');
                valid = false;
            }

            if (emailInput) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // format basique d'un email
                if (!emailRegex.test(emailInput.value.trim())) {
                    showError(emailInput, 'Email invalide');
                    valid = false;
                }
            }

            if (!valid) e.preventDefault(); // bloquer l'envoi si un champ est invalide
        });

        // Vérifier un champ individuel (appelé au blur)
        function validateField(input) {
            if (input.id === 'nom' && !input.value.trim()) {
                showError(input, 'Le nom est requis');
            } else if (input.id === 'email') {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(input.value.trim())) showError(input, 'Email invalide');
            }
        }

        // Afficher un message d'erreur rouge sous le champ
        function showError(input, msg) {
            clearError(input); // d'abord supprimer l'ancienne erreur s'il y en a une
            input.style.borderColor = 'var(--danger)'; // bordure rouge
            const err = document.createElement('span');
            err.className   = 'field-error';
            err.textContent = '⚠️ ' + msg;
            input.parentNode.appendChild(err); // ajouter le message sous le champ
        }

        // Supprimer le message d'erreur d'un champ
        function clearError(input) {
            input.style.borderColor = ''; // remettre la bordure normale
            input.parentNode.querySelector('.field-error')?.remove(); // supprimer le span d'erreur
        }
    }


    /* ============================================================
       7. ANIMATION D'ENTRÉE DES CARTES PRODUITS
       Les cartes apparaissent progressivement avec un effet de
       glissement vers le haut, au fur et à mesure qu'elles
       entrent dans la zone visible de l'écran (scroll).
    ============================================================ */

    // IntersectionObserver surveille quand un élément devient visible à l'écran
    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry, i) => {
            if (entry.isIntersecting) { // si la carte est maintenant visible...
                setTimeout(() => {
                    entry.target.style.opacity   = '1';          // apparaître
                    entry.target.style.transform = 'translateY(0)'; // revenir à la position normale
                }, i * 60); // délai décalé pour chaque carte (effet cascade)

                observer.unobserve(entry.target); // ne plus surveiller cette carte (animation unique)
            }
        });
    }, { threshold: 0.1 }); // déclencher quand 10% de la carte est visible

    // Initialiser toutes les cartes : cachées et décalées vers le bas
    productCards.forEach(card => {
        card.style.opacity   = '0';
        card.style.transform = 'translateY(20px)'; // décalage initial vers le bas
        card.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
        observer.observe(card); // commencer à surveiller cette carte
    });


    /* ============================================================
       8. BOUTON RETOUR EN HAUT ↑
       Un bouton discret apparaît en bas à gauche quand l'utilisateur
       a suffisamment scrollé vers le bas. Un clic ramène en haut.
    ============================================================ */

    const scrollBtn = document.getElementById('scroll-top');
    if (scrollBtn) {
        // Afficher ou cacher le bouton selon la position de scroll
        window.addEventListener('scroll', () => {
            const visible = window.scrollY > 400; // visible si on a scrollé plus de 400px
            scrollBtn.style.opacity       = visible ? '1' : '0';
            scrollBtn.style.pointerEvents = visible ? ''  : 'none'; // cliquable seulement si visible
        });

        // Remonter en haut de la page en douceur au clic
        scrollBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }


}); // fin de DOMContentLoaded
