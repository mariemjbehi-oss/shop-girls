<?php
// login.php — Page de connexion
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Si déjà connecté → rediriger
if (estConnecte()) {
    header('Location: ' . (estAdmin() ? 'admin.php' : 'index.php'));
    exit;
}

$erreur = '';
$email  = '';

// Traitement du formulaire de connexion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email      = trim($_POST['email']      ?? '');
    $mot_de_passe = trim($_POST['mot_de_passe'] ?? '');

    if (empty($email) || empty($mot_de_passe)) {
        $erreur = "Veuillez remplir tous les champs.";
    } else {
        $user = connecterUtilisateur($email, $mot_de_passe);
        if ($user) {
            // Connexion réussie → rediriger selon le rôle
            $_SESSION['flash'] = "🌸 Bienvenue, " . $user['nom'] . " !";
            header('Location: ' . ($user['role'] === 'admin' ? 'admin.php' : 'index.php'));
            exit;
        } else {
            $erreur = "Email ou mot de passe incorrect.";
        }
    }
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Belle & Rose — Connexion</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Page centrée */
        .login-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #fdf0f4 0%, #fff5f0 50%, #fdf0f7 100%);
            padding: 2rem;
        }

        .login-card {
            background: white;
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 3rem 2.5rem;
            width: 100%;
            max-width: 420px;
            box-shadow: 0 20px 60px rgba(200,116,138,0.15);
            text-align: center;
        }

        .login-logo {
            font-family: 'Playfair Display', serif;
            font-size: 2.2rem;
            font-weight: 800;
            color: var(--accent);
            font-style: italic;
            margin-bottom: 0.3rem;
        }

        .login-subtitle {
            font-size: 0.78rem;
            color: var(--gold);
            letter-spacing: 3px;
            text-transform: uppercase;
            font-weight: 600;
            margin-bottom: 2rem;
        }

        .login-title {
            font-family: 'Playfair Display', serif;
            font-size: 1.3rem;
            color: var(--text);
            margin-bottom: 0.4rem;
        }

        .login-desc {
            color: var(--text-muted);
            font-size: 0.85rem;
            margin-bottom: 2rem;
        }

        .login-form .form-group {
            text-align: left;
            margin-bottom: 1.2rem;
        }

        .login-form input {
            width: 100%;
            background: var(--bg);
            border: 1px solid var(--border);
            color: var(--text);
            padding: 0.85rem 1rem;
            border-radius: 12px;
            font-family: 'Jost', sans-serif;
            font-size: 0.95rem;
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        .login-form input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(200,116,138,0.12);
        }

        .btn-login {
            width: 100%;
            padding: 0.95rem;
            font-size: 1rem;
            font-weight: 600;
            letter-spacing: 0.5px;
            border-radius: 50px;
            margin-top: 0.5rem;
        }

        .login-footer {
            margin-top: 1.5rem;
            font-size: 0.82rem;
            color: var(--text-muted);
        }

        .login-footer a {
            color: var(--accent);
            text-decoration: none;
            font-weight: 500;
        }

        /* Comptes de test */
        .test-accounts {
            margin-top: 1.8rem;
            padding: 1.2rem;
            background: var(--accent-light);
            border-radius: 12px;
            border: 1px dashed var(--accent2);
            text-align: left;
        }

        .test-accounts p {
            font-size: 0.78rem;
            color: var(--text-muted);
            margin-bottom: 0.5rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .test-account-row {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem 0;
            border-bottom: 1px solid var(--border);
            cursor: pointer;
        }

        .test-account-row:last-child { border-bottom: none; }

        .test-account-row:hover { opacity: 0.8; }

        .account-role {
            font-size: 0.72rem;
            font-weight: 700;
            padding: 0.2rem 0.6rem;
            border-radius: 50px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }

        .role-admin  { background: var(--accent); color: white; }
        .role-client { background: var(--gold);   color: white; }

        .account-info {
            font-size: 0.8rem;
            color: var(--text);
            line-height: 1.4;
        }

        .account-info small { color: var(--text-muted); display: block; }
    </style>
</head>
<body>

<div class="login-wrapper">
    <div class="login-card">

        <!-- Logo -->
        <div class="login-logo">Belle & Rose</div>
        <div class="login-subtitle">✦ Beauté & Organisation</div>

        <h2 class="login-title">Connexion</h2>
        <p class="login-desc">Accédez à votre espace personnel</p>

        <!-- Message flash -->
        <?php if ($flash): ?>
            <div class="alert alert-info" style="margin-bottom:1.2rem"><?= htmlspecialchars($flash) ?></div>
        <?php endif; ?>

        <!-- Erreur -->
        <?php if ($erreur): ?>
            <div class="alert alert-error" style="margin-bottom:1.2rem">⚠️ <?= htmlspecialchars($erreur) ?></div>
        <?php endif; ?>

        <!-- Formulaire -->
        <form id="login-form" class="login-form" method="POST" action="login.php">
            <div class="form-group">
                <label for="email">Adresse e-mail</label>
                <input type="email" id="email" name="email"
                       value="<?= htmlspecialchars($email) ?>"
                       placeholder="votre@email.com" required>
            </div>
            <div class="form-group">
                <label for="mot_de_passe">Mot de passe</label>
                <input type="password" id="mot_de_passe" name="mot_de_passe"
                       placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn btn-primary btn-login">
                🌸 Se connecter
            </button>
        </form>

        <div class="login-footer">
            Pas encore de compte ?
            <a href="register.php">Créer un compte</a>
        </div>

        <!-- Comptes de test (cliquer pour remplir automatiquement) -->
        <div class="test-accounts">
            <p>🔑 Comptes de démonstration — cliquer pour remplir :</p>

            <div class="test-account-row"
                 onclick="fillLogin('admin@bellerose.com','admin123')">
                <span class="account-role role-admin">👑 Admin</span>
                <div class="account-info">
                    admin@bellerose.com
                    <small>Mot de passe : admin123</small>
                </div>
            </div>

            <div class="test-account-row"
                 onclick="fillLogin('sophie@exemple.com','client123')">
                <span class="account-role role-client">🌸 Cliente</span>
                <div class="account-info">
                    sophie@exemple.com
                    <small>Mot de passe : client123</small>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
// Remplir automatiquement le formulaire au clic sur un compte de démo
function fillLogin(email, mdp) {
    document.getElementById('email').value         = email;
    document.getElementById('mot_de_passe').value  = mdp;
    // Petite animation pour montrer que c'est rempli
    document.getElementById('email').style.borderColor         = 'var(--accent)';
    document.getElementById('mot_de_passe').style.borderColor  = 'var(--accent)';
    setTimeout(() => {
        document.getElementById('email').style.borderColor        = '';
        document.getElementById('mot_de_passe').style.borderColor = '';
    }, 1000);
}

// Validation côté client
document.getElementById('login-form').addEventListener('submit', (e) => {
    const email = document.getElementById('email').value.trim();
    const mdp   = document.getElementById('mot_de_passe').value.trim();
    if (!email || !mdp) {
        e.preventDefault();
        alert('Veuillez remplir tous les champs.');
    }
});
</script>
</body>
</html>
