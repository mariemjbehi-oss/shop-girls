<?php
// panier_action.php — Traitement des actions du panier
require_once 'includes/panier.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

    case 'ajouter':
        $id  = (int)($_POST['produit_id'] ?? 0);
        $nom = $_POST['nom'] ?? '';
        $prix = (float)($_POST['prix'] ?? 0);
        if ($id > 0 && $nom && $prix > 0) {
            ajouterAuPanier($id, $nom, $prix);
            $_SESSION['flash'] = "✅ \"$nom\" ajouté au panier";
        }
        header('Location: index.php');
        exit;

    case 'modifier':
        $id  = (int)($_POST['produit_id'] ?? 0);
        $qty = (int)($_POST['quantite'] ?? 0);
        if ($id > 0) {
            modifierQuantite($id, $qty);
        }
        header('Location: panier.php');
        exit;

    case 'supprimer':
        $id = (int)($_GET['id'] ?? 0);
        if ($id > 0) {
            supprimerDuPanier($id);
        }
        header('Location: panier.php');
        exit;

    case 'vider':
        viderPanier();
        header('Location: panier.php');
        exit;

    default:
        header('Location: index.php');
        exit;
}
