<?php
// admin.php — Tableau de bord Administratrice
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Seul l'admin peut accéder
exigerAdmin();

$pdo = getConnection();

// Statistiques
$nb_produits   = $pdo->query("SELECT COUNT(*) FROM produits")->fetchColumn();
$nb_commandes  = $pdo->query("SELECT COUNT(*) FROM commandes")->fetchColumn();
$nb_clients    = $pdo->query("SELECT COUNT(*) FROM utilisateurs WHERE role='client'")->fetchColumn();
$chiffre_affaires = $pdo->query("SELECT COALESCE(SUM(total),0) FROM commandes")->fetchColumn();

// Dernières commandes
$commandes = $pdo->query("
    SELECT * FROM commandes ORDER BY created_at DESC LIMIT 10
")->fetchAll();

// Tous les produits
$produits = $pdo->query("
    SELECT p.*, c.nom AS categorie_nom
    FROM produits p
    LEFT JOIN categories c ON p.categorie_id = c.id
    ORDER BY p.id
")->fetchAll();

$user  = utilisateurConnecte();
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Belle & Rose — Administration</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body { background: #fdf6f0; }

        /* Sidebar admin */
        .admin-layout { display: flex; min-height: 100vh; }

        .sidebar {
            width: 240px; min-height: 100vh;
            background: white;
            border-right: 1px solid var(--border);
            padding: 2rem 1.5rem;
            position: fixed; top: 0; left: 0;
            display: flex; flex-direction: column;
            box-shadow: 4px 0 20px rgba(200,116,138,0.08);
        }

        .sidebar-brand {
            font-family: 'Playfair Display', serif;
            font-size: 1.4rem; font-weight: 800;
            color: var(--accent); font-style: italic;
            margin-bottom: 0.3rem;
        }

        .sidebar-role {
            font-size: 0.7rem; color: var(--gold);
            letter-spacing: 2px; text-transform: uppercase;
            font-weight: 600; margin-bottom: 2rem;
        }

        .sidebar-menu { flex: 1; }

        .sidebar-item {
            display: flex; align-items: center; gap: 0.75rem;
            padding: 0.7rem 1rem;
            border-radius: 10px;
            text-decoration: none;
            color: var(--text-muted);
            font-size: 0.88rem; font-weight: 500;
            margin-bottom: 0.3rem;
            transition: all 0.2s;
        }

        .sidebar-item:hover, .sidebar-item.active {
            background: var(--accent-light);
            color: var(--accent);
        }

        .sidebar-divider {
            height: 1px; background: var(--border);
            margin: 1rem 0;
        }

        .sidebar-logout {
            display: flex; align-items: center; gap: 0.75rem;
            padding: 0.7rem 1rem;
            border-radius: 10px;
            text-decoration: none;
            color: var(--danger);
            font-size: 0.88rem; font-weight: 500;
            background: rgba(200,116,116,0.06);
            border: 1px solid rgba(200,116,116,0.15);
            transition: all 0.2s;
        }

        .sidebar-logout:hover { background: rgba(200,116,116,0.12); }

        /* Contenu principal */
        .admin-content {
            margin-left: 240px;
            padding: 2rem;
            flex: 1;
        }

        .admin-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 2rem;
        }

        .admin-header h1 {
            font-family: 'Playfair Display', serif;
            font-size: 1.8rem; font-weight: 700;
            color: var(--text);
        }

        .admin-user {
            display: flex; align-items: center; gap: 0.75rem;
            background: white;
            border: 1px solid var(--border);
            padding: 0.5rem 1.2rem;
            border-radius: 50px;
            font-size: 0.85rem;
        }

        /* Stat cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1.25rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: white;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 1.5rem;
            box-shadow: var(--shadow);
            text-align: center;
        }

        .stat-icon { font-size: 2rem; margin-bottom: 0.5rem; }
        .stat-value {
            font-family: 'Playfair Display', serif;
            font-size: 2rem; font-weight: 800;
            color: var(--accent);
        }

        .stat-label { color: var(--text-muted); font-size: 0.82rem; margin-top: 0.2rem; }

        /* Section cards */
        .admin-section {
            background: white;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
            overflow: hidden;
        }

        .section-header {
            padding: 1.2rem 1.5rem;
            border-bottom: 1px solid var(--border);
            background: linear-gradient(135deg, #fff5f7, #fff9f5);
            display: flex; align-items: center; justify-content: space-between;
        }

        .section-header h2 {
            font-family: 'Playfair Display', serif;
            font-size: 1.1rem; font-weight: 700;
            color: var(--text);
        }

        .admin-table { width: 100%; border-collapse: collapse; }
        .admin-table th {
            padding: 0.9rem 1.2rem;
            text-align: left;
            font-size: 0.75rem; font-weight: 700;
            text-transform: uppercase; letter-spacing: 1px;
            color: var(--text-muted);
            background: var(--bg);
            border-bottom: 1px solid var(--border);
        }
        .admin-table td {
            padding: 0.9rem 1.2rem;
            border-bottom: 1px solid var(--border);
            font-size: 0.88rem;
            color: var(--text);
        }
        .admin-table tr:last-child td { border-bottom: none; }
        .admin-table tr:hover td { background: #fff9fb; }

        .badge-statut {
            padding: 0.2rem 0.75rem;
            border-radius: 50px;
            font-size: 0.72rem;
            font-weight: 700;
            text-transform: uppercase;
        }

        .badge-confirmee { background: rgba(124,173,138,0.15); color: #5a8a6a; }
        .badge-attente   { background: rgba(201,169,110,0.15); color: #996600; }

        .produit-img {
            width: 40px; height: 40px;
            object-fit: cover;
            border-radius: 8px;
            border: 1px solid var(--border);
        }

        @media (max-width: 900px) {
            .stats-grid { grid-template-columns: repeat(2,1fr); }
            .sidebar { display: none; }
            .admin-content { margin-left: 0; }
        }
    </style>
</head>
<body>

<div class="admin-layout">

    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-brand">Belle & Rose</div>
        <div class="sidebar-role">👑 Administration</div>

        <nav class="sidebar-menu">
            <a href="admin.php" class="sidebar-item active">📊 Tableau de bord</a>
            <a href="index.php" class="sidebar-item">🛍️ Voir la boutique</a>
        </nav>

        <div class="sidebar-divider"></div>

        <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:0.75rem;padding:0 0.5rem">
            Connectée en tant que<br>
            <strong style="color:var(--text)"><?= htmlspecialchars($user['nom']) ?></strong>
        </div>

        <a href="logout.php" class="sidebar-logout">🚪 Déconnexion</a>
    </aside>

    <!-- Contenu -->
    <main class="admin-content">

        <div class="admin-header">
            <h1>Tableau de bord 📊</h1>
            <div class="admin-user">
                👑 <?= htmlspecialchars($user['nom']) ?>
            </div>
        </div>

        <?php if ($flash): ?>
            <div class="alert alert-info" style="margin-bottom:1.5rem"><?= htmlspecialchars($flash) ?></div>
        <?php endif; ?>

        <!-- Statistiques -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">📦</div>
                <div class="stat-value"><?= $nb_produits ?></div>
                <div class="stat-label">Produits</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">🛍️</div>
                <div class="stat-value"><?= $nb_commandes ?></div>
                <div class="stat-label">Commandes</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">👩</div>
                <div class="stat-value"><?= $nb_clients ?></div>
                <div class="stat-label">Clientes</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">💰</div>
                <div class="stat-value"><?= number_format($chiffre_affaires, 0) ?></div>
                <div class="stat-label">TND — Chiffre d'affaires</div>
            </div>
        </div>

        <!-- Dernières commandes -->
        <div class="admin-section">
            <div class="section-header">
                <h2>🛍️ Dernières commandes</h2>
                <span style="font-size:0.8rem;color:var(--text-muted)"><?= $nb_commandes ?> au total</span>
            </div>
            <?php if (empty($commandes)): ?>
                <div style="padding:2rem;text-align:center;color:var(--text-muted)">Aucune commande pour le moment</div>
            <?php else: ?>
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Cliente</th>
                        <th>Email</th>
                        <th>Total</th>
                        <th>Statut</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($commandes as $cmd): ?>
                    <tr>
                        <td><strong style="color:var(--accent)">#<?= str_pad($cmd['id'], 4, '0', STR_PAD_LEFT) ?></strong></td>
                        <td><?= htmlspecialchars($cmd['nom_client']) ?></td>
                        <td style="color:var(--text-muted)"><?= htmlspecialchars($cmd['email_client']) ?></td>
                        <td><strong><?= number_format($cmd['total'], 2) ?> TND</strong></td>
                        <td>
                            <span class="badge-statut <?= $cmd['statut']==='confirmée' ? 'badge-confirmee' : 'badge-attente' ?>">
                                <?= htmlspecialchars($cmd['statut']) ?>
                            </span>
                        </td>
                        <td style="color:var(--text-muted)"><?= date('d/m/Y H:i', strtotime($cmd['created_at'])) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>

        <!-- Liste des produits -->
        <div class="admin-section">
            <div class="section-header">
                <h2>📦 Catalogue produits</h2>
                <span style="font-size:0.8rem;color:var(--text-muted)"><?= $nb_produits ?> produits</span>
            </div>
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Photo</th>
                        <th>Produit</th>
                        <th>Catégorie</th>
                        <th>Prix</th>
                        <th>Stock</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($produits as $p): ?>
                    <tr>
                        <td>
                            <img class="produit-img"
                                 src="<?= htmlspecialchars($p['image_url'] ?? '') ?>"
                                 alt=""
                                 onerror="this.style.display='none'">
                        </td>
                        <td><strong><?= htmlspecialchars($p['nom']) ?></strong></td>
                        <td style="color:var(--accent)"><?= htmlspecialchars($p['categorie_nom'] ?? '') ?></td>
                        <td><strong><?= number_format($p['prix'], 2) ?> TND</strong></td>
                        <td>
                            <span style="color:<?= $p['stock'] < 10 ? 'var(--danger)' : 'var(--success)' ?>">
                                <?= $p['stock'] ?> unités
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    </main>
</div>

<script src="js/app.js"></script>
</body>
</html>
