<?php
// index.php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/panier.php';
require_once 'includes/produits.php';

// On charge TOUS les produits — le filtrage se fait en JS côté client
$categories = getCategories();
$produits   = getTousProduits();

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$emojis = ['Soin du visage' => '🌸', 'Maquillage' => '💄', 'Parfums & Corps' => '✨', 'Organisation' => '🗂️'];
$badges = ['Soin du visage' => 'Best-seller', 'Maquillage' => 'Nouveau', 'Parfums & Corps' => 'Exclusif', 'Organisation' => 'Tendance'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Belle & Rose — Boutique Beauté</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php require_once 'includes/nav.php'; ?>

<div class="hero">
    <div class="hero-deco">🌸</div>
    <h1>La beauté,<br><em>c'est vous.</em></h1>
    <p>Soins, maquillage et organisation — tout ce qu'il vous faut pour vous sentir belle au quotidien.</p>
    <div class="hero-badges">
        <span class="hero-badge">🚚 Livraison gratuite</span>
        <span class="hero-badge">💝 100% naturel</span>
        <span class="hero-badge">✨ Qualité premium</span>
    </div>
</div>

<div class="container">

    <?php if ($flash): ?>
        <div class="flash"><?= htmlspecialchars($flash) ?></div>
    <?php endif; ?>

    <!-- Recherche live (JS) -->
    <div class="search-bar">
        <input class="search-input" type="text" placeholder="🔍  Rechercher un produit beauté...">
        <button id="clear-search" class="btn btn-secondary" style="display:none">✕</button>
    </div>

    <!-- Filtres — gérés entièrement en JS, data-cat pour le filtrage -->
    <div class="filters">
        <a class="filter-btn active" data-cat="all" data-label="Nos Essentiels Beauté" href="#">
            🌷 Tout voir
        </a>
        <?php foreach ($categories as $cat): ?>
            <a class="filter-btn"
               data-cat="<?= $cat['id'] ?>"
               data-label="<?= $emojis[$cat['nom']] ?? '' ?> <?= htmlspecialchars($cat['nom']) ?>"
               href="#">
                <?= $emojis[$cat['nom']] ?? '✦' ?> <?= htmlspecialchars($cat['nom']) ?>
            </a>
        <?php endforeach; ?>
    </div>

    <h2 class="section-title" id="section-title">Nos Essentiels Beauté</h2>

    <!-- Grille produits — data-cat sur chaque carte pour le filtrage JS -->
    <?php if (empty($produits)): ?>
        <div class="empty-state">
            <div class="icon">🌸</div>
            <h3>Aucun produit trouvé</h3>
            <p>Explorez nos catégories beauté</p>
        </div>
    <?php else: ?>
    <div class="products-grid">
        <?php foreach ($produits as $p): ?>
        <div class="product-card" data-cat="<?= $p['categorie_id'] ?>">
            <div class="product-image">
                <?php if (!empty($p['image_url'])): ?>
                    <img src="<?= htmlspecialchars($p['image_url']) ?>"
                         alt="<?= htmlspecialchars($p['nom']) ?>"
                         loading="lazy"
                         onerror="this.parentElement.innerHTML='<div class=\'product-image-fallback\'><?= $emojis[$p['categorie_nom']] ?? '🌸' ?></div>'">
                    <span class="product-badge"><?= $badges[$p['categorie_nom']] ?? 'Nouveau' ?></span>
                <?php else: ?>
                    <div class="product-image-fallback"><?= $emojis[$p['categorie_nom']] ?? '🌸' ?></div>
                <?php endif; ?>
            </div>
            <div class="product-info">
                <div class="product-category"><?= htmlspecialchars($p['categorie_nom'] ?? '') ?></div>
                <div class="product-name"><?= htmlspecialchars($p['nom']) ?></div>
                <div class="product-desc"><?= htmlspecialchars($p['description'] ?? '') ?></div>
                <div class="product-footer">
                    <span class="product-price"><?= number_format($p['prix'], 2) ?> <?= CURRENCY ?></span>
                    <form method="POST" action="panier_action.php">
                        <input type="hidden" name="action" value="ajouter">
                        <input type="hidden" name="produit_id" value="<?= $p['id'] ?>">
                        <input type="hidden" name="nom" value="<?= htmlspecialchars($p['nom']) ?>">
                        <input type="hidden" name="prix" value="<?= $p['prix'] ?>">
                        <button type="submit" class="btn btn-primary btn-sm">+ Ajouter</button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

</div>

<!-- Bouton retour en haut -->
<button id="scroll-top" title="Retour en haut">↑</button>

<script src="js/app.js"></script>
</body>
</html>
