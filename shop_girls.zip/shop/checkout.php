<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/panier.php';
require_once 'includes/commandes.php';

if (panierEstVide()) { header('Location: panier.php'); exit; }

$erreurs = [];
$nom = $email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom   = trim($_POST['nom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    if (empty($nom))   $erreurs[] = "Le nom est requis.";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $erreurs[] = "L'adresse e-mail est invalide.";
    if (empty($erreurs)) {
        $commande_id = enregistrerCommande($nom, $email);
        if ($commande_id) { viderPanier(); header("Location: confirmation.php?id=$commande_id"); exit; }
        else $erreurs[] = "Une erreur est survenue. Veuillez réessayer.";
    }
}

$panier = getPanier();
$total  = calculerTotal();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Belle & Rose — Finaliser ma commande</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php require_once 'includes/nav.php'; ?>

<div class="container">
    <h1 class="section-title" style="margin-top:2rem">💳 Finaliser ma commande</h1>

    <?php if (!empty($erreurs)): ?>
        <div class="alert alert-error">
            <?php foreach ($erreurs as $e): ?>
                <div>⚠️ <?= htmlspecialchars($e) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="checkout-grid">
        <div class="form-card">
            <h2>📦 Informations de livraison</h2>
            <!-- id="checkout-form" ciblé par JS pour la validation live -->
            <form id="checkout-form" method="POST" action="checkout.php">
                <div class="form-group">
                    <label for="nom">Nom complet *</label>
                    <input type="text" id="nom" name="nom"
                           value="<?= htmlspecialchars($nom) ?>"
                           placeholder="Votre nom" required>
                </div>
                <div class="form-group">
                    <label for="email">Adresse e-mail *</label>
                    <input type="email" id="email" name="email"
                           value="<?= htmlspecialchars($email) ?>"
                           placeholder="votre@email.com" required>
                </div>
                <div class="alert alert-info" style="margin-top:1rem">
                    🌸 Livraison offerte sur toutes vos commandes !
                </div>
                <button type="submit" class="btn btn-primary"
                        style="width:100%;padding:0.9rem;font-size:1rem;margin-top:1rem;border-radius:50px;">
                    ✦ Confirmer ma commande
                </button>
            </form>
        </div>

        <div class="order-summary">
            <h3>🛍️ Votre commande (<?= getNombreArticles() ?> articles)</h3>
            <?php foreach ($panier as $item): ?>
                <div class="summary-row">
                    <span><?= htmlspecialchars($item['nom']) ?> × <?= $item['quantite'] ?></span>
                    <span><?= number_format($item['prix'] * $item['quantite'], 2) ?> <?= CURRENCY ?></span>
                </div>
            <?php endforeach; ?>
            <div class="summary-row"><span>Livraison</span><span style="color:var(--success)">Gratuite</span></div>
            <div class="summary-total">
                <span>Total</span>
                <span><?= number_format($total, 2) ?> <?= CURRENCY ?></span>
            </div>
            <a href="panier.php" class="btn btn-secondary" style="display:block;text-align:center;margin-top:1rem">
                ← Modifier le panier
            </a>
        </div>
    </div>
</div>

<script src="js/app.js"></script>
</body>
</html>
