<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/panier.php';

$panier     = getPanier();
$total      = calculerTotal();
$nbArticles = getNombreArticles();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Belle & Rose — Mon Panier</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php require_once 'includes/nav.php'; ?>

<div class="container">
    <h1 class="section-title" style="margin-top:2rem">🛍️ Mon Panier</h1>

    <?php if (panierEstVide()): ?>
        <div class="empty-state">
            <div class="icon">🌸</div>
            <h3>Votre panier est vide</h3>
            <p>Découvrez nos produits beauté et organisation</p>
            <a href="index.php" class="btn btn-primary" style="margin-top:1.5rem">Voir la boutique</a>
        </div>
    <?php else: ?>
        <div class="cart-wrapper">
            <div>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Produit</th>
                                <th>Prix unitaire</th>
                                <th>Quantité</th>
                                <!-- data-prix sur chaque TR pour que JS calcule le sous-total -->
                                <th>Sous-total</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($panier as $item): ?>
                            <tr data-prix="<?= $item['prix'] ?>">
                                <td><strong style="font-family:'Playfair Display',serif"><?= htmlspecialchars($item['nom']) ?></strong></td>
                                <td><?= number_format($item['prix'], 2) ?> <?= CURRENCY ?></td>
                                <td>
                                    <form method="POST" action="panier_action.php" class="qty-form">
                                        <input type="hidden" name="action" value="modifier">
                                        <input type="hidden" name="produit_id" value="<?= $item['id'] ?>">
                                        <!-- qty-input déclenche recalcul JS en temps réel -->
                                        <input class="qty-input" type="number" name="quantite"
                                               value="<?= $item['quantite'] ?>" min="0" max="99">
                                        <button class="btn btn-secondary btn-sm" type="submit">✓</button>
                                    </form>
                                </td>
                                <!-- .subtotal mis à jour par JS -->
                                <td><strong class="subtotal" style="color:var(--accent-dark)">
                                    <?= number_format($item['prix'] * $item['quantite'], 2) ?> <?= CURRENCY ?>
                                </strong></td>
                                <td>
                                    <!-- btn-supprimer géré par JS (modal custom) -->
                                    <a href="panier_action.php?action=supprimer&id=<?= $item['id'] ?>"
                                       class="btn btn-danger btn-sm btn-supprimer">🗑️</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div style="margin-top:1rem;display:flex;gap:0.75rem">
                    <a href="index.php" class="btn btn-secondary">← Continuer mes achats</a>
                    <!-- btn-vider géré par JS (modal custom) -->
                    <a href="panier_action.php?action=vider" class="btn btn-danger btn-vider">🗑️ Vider le panier</a>
                </div>
            </div>

            <div class="order-summary">
                <h3>💝 Récapitulatif</h3>
                <?php foreach ($panier as $item): ?>
                    <div class="summary-row">
                        <span><?= htmlspecialchars($item['nom']) ?> × <?= $item['quantite'] ?></span>
                        <span><?= number_format($item['prix'] * $item['quantite'], 2) ?> <?= CURRENCY ?></span>
                    </div>
                <?php endforeach; ?>
                <div class="summary-row">
                    <span>Livraison</span>
                    <span style="color:var(--success)">✦ Gratuite</span>
                </div>
                <div class="summary-total">
                    <span>Total</span>
                    <!-- #cart-total mis à jour par JS quand qty change -->
                    <span id="cart-total"><?= number_format($total, 2) ?> <?= CURRENCY ?></span>
                </div>
                <a href="checkout.php" class="btn btn-primary btn-checkout">Commander →</a>
            </div>
        </div>
    <?php endif; ?>
</div>

<button id="scroll-top" title="Retour en haut">↑</button>
<script src="js/app.js"></script>
</body>
</html>
