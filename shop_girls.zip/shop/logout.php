<?php
// logout.php — Déconnexion
require_once 'includes/config.php';
require_once 'includes/auth.php';

deconnecterUtilisateur();

$_SESSION['flash'] = "👋 Vous avez été déconnectée. À bientôt !";
header('Location: login.php');
exit;
