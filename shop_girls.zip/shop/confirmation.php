<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/commandes.php';

$commande_id = (int)($_GET['id'] ?? 0);
$commande = $commande_id > 0 ? getCommandeDetails($commande_id) : null;
if (!$commande) { header('Location: index.php'); exit; }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Belle & Rose — Commande confirmée !</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php require_once 'includes/nav.php'; ?>
<div class="container">
    <div class="success-card">
        <div class="success-icon">🌸</div>
        <h1>Merci pour votre commande !</h1>
        <p style="color:var(--text-muted);margin-bottom:0.5rem">
            Bonjour <strong><?= htmlspecialchars($commande['nom_client']) ?></strong>, votre commande est confirmée avec amour 💝
        </p>
        <div class="order-number">Commande #<?= str_pad($commande['id'], 5, '0', STR_PAD_LEFT) ?></div>
        <div class="order-recap">
            <?php foreach ($commande['lignes'] as $ligne): ?>
                <div class="recap-row">
                    <span><?= htmlspecialchars($ligne['produit_nom']) ?> × <?= $ligne['quantite'] ?></span>
                    <span><?= number_format($ligne['prix_unitaire'] * $ligne['quantite'], 2) ?> <?= CURRENCY ?></span>
                </div>
            <?php endforeach; ?>
            <div class="recap-row">
                <span>Total payé</span>
                <span style="color:var(--accent)"><?= number_format($commande['total'], 2) ?> <?= CURRENCY ?></span>
            </div>
        </div>
        <p style="color:var(--text-muted);font-size:0.88rem;line-height:1.6">
            📧 Un e-mail de confirmation sera envoyé à <strong><?= htmlspecialchars($commande['email_client']) ?></strong>
        </p>
        <div style="margin-top:2rem">
            <a href="index.php" class="btn btn-primary" style="padding:0.8rem 2rem">🌸 Continuer mes achats</a>
        </div>
    </div>
</div>
</body>
</html>
