<?php
// install.php — Script d'installation des comptes utilisateurs
// Ouvrir UNE SEULE FOIS via : http://localhost/panier-app/install.php
// Puis SUPPRIMER ce fichier pour la sécurité !

require_once 'includes/config.php';

$pdo = getConnection();

// Générer les mots de passe hashés
$hash_admin  = password_hash('admin123',  PASSWORD_DEFAULT);
$hash_client = password_hash('client123', PASSWORD_DEFAULT);

try {
    // Supprimer les anciens comptes s'ils existent
    $pdo->exec("DELETE FROM utilisateurs WHERE email IN ('admin@bellerose.com','sophie@exemple.com')");

    // Insérer Admin
    $stmt = $pdo->prepare("INSERT INTO utilisateurs (nom, email, mot_de_passe, role) VALUES (:nom, :email, :mdp, :role)");
    $stmt->execute([':nom'=>'Administratrice', ':email'=>'admin@bellerose.com', ':mdp'=>$hash_admin,  ':role'=>'admin']);
    $stmt->execute([':nom'=>'Sophie Martin',   ':email'=>'sophie@exemple.com',  ':mdp'=>$hash_client, ':role'=>'client']);

    echo "<h2 style='color:green;font-family:Arial'>✅ Comptes créés avec succès !</h2>";
    echo "<p><b>Admin :</b> admin@bellerose.com / admin123</p>";
    echo "<p><b>Client :</b> sophie@exemple.com / client123</p>";
    echo "<p style='color:red'><b>⚠️ Supprimez ce fichier maintenant !</b></p>";
    echo "<a href='login.php'>→ Aller à la connexion</a>";
} catch (Exception $e) {
    echo "Erreur : " . $e->getMessage();
}
