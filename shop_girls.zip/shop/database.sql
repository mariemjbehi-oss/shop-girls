-- ============================================
-- Base de données : Boutique Beauté & Organisation
-- PostgreSQL
-- ============================================

CREATE DATABASE shop_db;
\c shop_db;

CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    description TEXT
);

CREATE TABLE produits (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(150) NOT NULL,
    description TEXT,
    prix DECIMAL(10, 2) NOT NULL,
    stock INTEGER NOT NULL DEFAULT 0,
    image_url VARCHAR(500),
    categorie_id INTEGER REFERENCES categories(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE commandes (
    id SERIAL PRIMARY KEY,
    nom_client VARCHAR(150) NOT NULL,
    email_client VARCHAR(150) NOT NULL,
    total DECIMAL(10, 2) NOT NULL,
    statut VARCHAR(50) DEFAULT 'en_attente',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE lignes_commande (
    id SERIAL PRIMARY KEY,
    commande_id INTEGER REFERENCES commandes(id) ON DELETE CASCADE,
    produit_id INTEGER REFERENCES produits(id),
    quantite INTEGER NOT NULL,
    prix_unitaire DECIMAL(10, 2) NOT NULL
);

-- ============================================
-- TABLE UTILISATEURS
-- ============================================
CREATE TABLE utilisateurs (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(150) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    mot_de_passe VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'client',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ⚠️ Les mots de passe sont insérés via le script install.php
-- Admin  : admin@bellerose.com  / admin123
-- Client : sophie@exemple.com   / client123

-- Catégories
INSERT INTO categories (nom, description) VALUES
('Soin du visage', 'Soins hydratants, sérums et masques'),
('Maquillage', 'Rouge à lèvres, fond de teint et palettes'),
('Parfums & Corps', 'Parfums, huiles et soins corporels'),
('Organisation', 'Rangement, agendas et accessoires');

-- Produits
INSERT INTO produits (nom, description, prix, stock, image_url, categorie_id) VALUES
('Sérum Éclat Rose', 'Sérum à l''acide hyaluronique et extrait de rose. Hydrate et illumine la peau en 7 jours.', 49.90, 40, 'images/serum-eclat.jpg', 1),
('Crème de Nuit Velours', 'Crème riche en rétinol et huile d''argan. Régénère la peau pendant le sommeil.', 38.50, 55, 'images/creme-nuit.webp', 1),
('Masque Argile Rose', 'Masque purifiant à l''argile rose et à l''eau de rose. Resserre les pores visiblement.', 24.90, 80, 'images/masque-argile.jpg', 1),
('Palette Yeux "Golden Hour"', 'Palette de 12 ombres à paupières dorées et roses. Pigmentation intense longue tenue.', 34.90, 35, 'https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=600&q=80', 2),
('Rouge à Lèvres Satiné', 'Rouge à lèvres hydratant fini satiné. Enrichi en vitamine E. Couleur nude rosé.', 18.90, 90, 'images/rouge-levres.jpg', 2),
('Fond de Teint Nude', 'Fond de teint longue tenue SPF 30. Fini naturel et lumineux. 20 teintes disponibles.', 29.90, 60, 'images/fond-de-teint.jpg', 2),
('Eau de Parfum "Pétale"', 'Fragrance florale et musquée. Notes de rose, pivoine et bois de santal.', 69.90, 25, 'images/eau-parfum.jpg', 3),
('Huile Corps Dorée', 'Huile sèche scintillante à l''argan et à la rose. Peau soyeuse et lumineuse.', 32.90, 45, 'images/huile-corps.jpg', 3),
('Coffret Bain Luxe', 'Coffret de 5 bombes de bain effervescentes parfumées rose, lavande et vanille.', 27.90, 50, 'images/coffret-bain.png', 3),
('Agenda Fleuri 2025', 'Agenda semainier couverture rigide motif floral. Papier épais 120g/m², élastique fermoir.', 22.90, 70, 'images/agenda-fleuri.jpg', 4),
('Box Rangement Maquillage', 'Organisateur acrylique transparent 6 compartiments. Idéal pour vanité ou coiffeuse.', 31.90, 40, 'images/box-rangement.jpg', 4),
('Trousse de Maquillage Rose', 'Grande trousse imperméable rose blush avec miroir intégré. Nombreuses poches.', 19.90, 65, 'images/trousse-maquillage.jpg', 4);
