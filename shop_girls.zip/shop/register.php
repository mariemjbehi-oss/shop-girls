<?php
// register.php — Page d'inscription client
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (estConnecte()) { header('Location: index.php'); exit; }

$erreurs = [];
$nom = $email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom          = trim($_POST['nom']          ?? '');
    $email        = trim($_POST['email']        ?? '');
    $mot_de_passe = trim($_POST['mot_de_passe'] ?? '');
    $confirmation = trim($_POST['confirmation'] ?? '');

    if (empty($nom))          $erreurs[] = "Le nom est requis.";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL))
                              $erreurs[] = "Email invalide.";
    if (strlen($mot_de_passe) < 6)
                              $erreurs[] = "Le mot de passe doit faire au moins 6 caractères.";
    if ($mot_de_passe !== $confirmation)
                              $erreurs[] = "Les mots de passe ne correspondent pas.";

    if (empty($erreurs)) {
        $pdo = getConnection();
        // Vérifier si l'email existe déjà
        $check = $pdo->prepare("SELECT id FROM utilisateurs WHERE email = :email");
        $check->execute([':email' => $email]);
        if ($check->fetch()) {
            $erreurs[] = "Cet email est déjà utilisé.";
        } else {
            $hash = password_hash($mot_de_passe, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO utilisateurs (nom, email, mot_de_passe, role) VALUES (:nom, :email, :mdp, 'client')");
            $stmt->execute([':nom'=>$nom, ':email'=>$email, ':mdp'=>$hash]);
            $_SESSION['flash'] = "🌸 Compte créé ! Vous pouvez vous connecter.";
            header('Location: login.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Belle & Rose — Créer un compte</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .login-wrapper {
            min-height: 100vh;
            display: flex; align-items: center; justify-content: center;
            background: linear-gradient(135deg, #fdf0f4, #fff5f0, #fdf0f7);
            padding: 2rem;
        }
        .login-card {
            background: white;
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 2.5rem;
            width: 100%; max-width: 440px;
            box-shadow: 0 20px 60px rgba(200,116,138,0.15);
            text-align: center;
        }
        .login-logo { font-family:'Playfair Display',serif; font-size:2rem; font-weight:800; color:var(--accent); font-style:italic; margin-bottom:0.3rem; }
        .login-subtitle { font-size:0.75rem; color:var(--gold); letter-spacing:3px; text-transform:uppercase; font-weight:600; margin-bottom:1.5rem; }
        .login-form .form-group { text-align:left; margin-bottom:1rem; }
        .login-form input { width:100%; background:var(--bg); border:1px solid var(--border); color:var(--text); padding:0.8rem 1rem; border-radius:12px; font-family:'Jost',sans-serif; font-size:0.92rem; transition:border-color 0.2s; }
        .login-form input:focus { outline:none; border-color:var(--accent); box-shadow:0 0 0 3px rgba(200,116,138,0.12); }
        .btn-login { width:100%; padding:0.9rem; font-size:1rem; font-weight:600; border-radius:50px; margin-top:0.5rem; }
        .login-footer { margin-top:1.2rem; font-size:0.82rem; color:var(--text-muted); }
        .login-footer a { color:var(--accent); text-decoration:none; font-weight:500; }
        .strength-bar { height:4px; border-radius:4px; margin-top:0.4rem; background:#eee; overflow:hidden; }
        .strength-fill { height:100%; border-radius:4px; width:0; transition:width 0.3s, background 0.3s; }
    </style>
</head>
<body>
<div class="login-wrapper">
    <div class="login-card">
        <div class="login-logo">Belle & Rose</div>
        <div class="login-subtitle">✦ Créer un compte</div>

        <?php if (!empty($erreurs)): ?>
            <div class="alert alert-error" style="margin-bottom:1rem;text-align:left">
                <?php foreach ($erreurs as $e): ?>
                    <div>⚠️ <?= htmlspecialchars($e) ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form id="register-form" class="login-form" method="POST" action="register.php">
            <div class="form-group">
                <label for="nom">Nom complet</label>
                <input type="text" id="nom" name="nom" value="<?= htmlspecialchars($nom) ?>" placeholder="Votre nom" required>
            </div>
            <div class="form-group">
                <label for="email">Adresse e-mail</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($email) ?>" placeholder="votre@email.com" required>
            </div>
            <div class="form-group">
                <label for="mot_de_passe">Mot de passe <small>(min. 6 caractères)</small></label>
                <input type="password" id="mot_de_passe" name="mot_de_passe" placeholder="••••••••" required>
                <div class="strength-bar"><div class="strength-fill" id="strength-fill"></div></div>
            </div>
            <div class="form-group">
                <label for="confirmation">Confirmer le mot de passe</label>
                <input type="password" id="confirmation" name="confirmation" placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn btn-primary btn-login">🌸 Créer mon compte</button>
        </form>

        <div class="login-footer">
            Déjà un compte ? <a href="login.php">Se connecter</a>
        </div>
    </div>
</div>

<script>
// Indicateur de force du mot de passe
document.getElementById('mot_de_passe').addEventListener('input', function() {
    const val  = this.value;
    const fill = document.getElementById('strength-fill');
    let strength = 0;
    if (val.length >= 6)  strength++;
    if (val.length >= 10) strength++;
    if (/[A-Z]/.test(val)) strength++;
    if (/[0-9]/.test(val)) strength++;
    const colors = ['', '#f87171', '#fb923c', '#facc15', '#4ade80'];
    const widths = ['0%', '25%', '50%', '75%', '100%'];
    fill.style.width      = widths[strength];
    fill.style.background = colors[strength];
});
</script>
</body>
</html>
